package com.ai.gamelauncher.ui

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel()